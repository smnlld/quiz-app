import React from "react";
import Quiz from "./App1";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import {withRouter} from "react-router";

const Home = () => {
  return (
    <div>
      <Link to="/quiz">OPEN QUIZ</Link>
    </div>
  );
};

export default withRouter(Home);
