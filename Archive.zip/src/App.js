import React, { useState } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch, 
} from "react-router-dom";
import { useParams } from "react-router-dom";

import Quiz from "./App1";
import Home from "./Home";

export const App = () => {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={Home}>
        </Route>
        <Route exact path="/quiz" component={Quiz}>
        </Route>
      </Switch>
    </Router>
  );
};
export default App;
